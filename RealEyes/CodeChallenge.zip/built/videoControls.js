window.onload = function () {
    // Video
    var video = document.getElementById("video");
};
//# sourceMappingURL=videoControls.js.map