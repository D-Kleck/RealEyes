require.config({
    paths: {
        "knockout": "externals/knockout-3.4.0",
    }
});
//# sourceMappingURL=require-config.js.map