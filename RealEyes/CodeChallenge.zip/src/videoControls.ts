window.onload = function() {

  // Video
  var video = document.getElementById("video");
}
